import React from 'react';
import './App.css';

import Mixer from "./Mixer"

function App() {
  return (
    <div className="App">
      <Mixer />
    </div>
  );
}

export default App;
